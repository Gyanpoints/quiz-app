# Google Sheets → Quiz questions

You can prepare questions in Google Sheets, then turn them into a `questions.js` file.

---

## Method A – Copy / Paste (simplest, no script)

1. Create a Google Sheet with this header row:

| question | optionA | optionB | optionC | optionD | correct | solution |
|----------|---------|---------|---------|---------|---------|----------|

2. Fill your questions.  
   - **correct** = `1` for A, `2` for B, `3` for C, `4` for D  
   - (You can also type A, B, C, D)

3. Select all data (including header) → **Ctrl+C** (Copy)

4. Open the converter in your quiz app:  
   `tools/converter.html`

5. Paste into the box → click **Convert** → **Download questions.js**

6. Put the file in the `quizzes/` folder and add an entry in `config.js`.

---

## Method B – Download as CSV

1. In Google Sheets: **File → Download → Comma Separated Values (.csv)**

2. Open `tools/converter.html`

3. Upload the CSV file → Convert → Download `questions.js`

---

## Method C – Google Apps Script (export JS from the sheet)

Use this if you want a **Download questions.js** menu inside Google Sheets.

### 1. Create the sheet

Same columns as above:

`question | optionA | optionB | optionC | optionD | correct | solution`

### 2. Open Apps Script

In the sheet: **Extensions → Apps Script**

Delete any code in `Code.gs` and paste:

```javascript
/**
 * Adds a custom menu to export quiz questions as questions.js
 */
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('Quiz Export')
    .addItem('Download questions.js', 'exportQuestionsJs')
    .addToUi();
}

function exportQuestionsJs() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  const data = sheet.getDataRange().getValues();
  if (data.length < 2) {
    SpreadsheetApp.getUi().alert('Need a header row and at least one question.');
    return;
  }

  const header = data[0].map(h => String(h).toLowerCase().trim().replace(/\s+/g, ''));
  const col = (names) => {
    for (const n of names) {
      const i = header.indexOf(n);
      if (i !== -1) return i;
    }
    return -1;
  };

  const qCol = col(['question', 'q']);
  const aCol = col(['optiona', 'option1', 'a']);
  const bCol = col(['optionb', 'option2', 'b']);
  const cCol = col(['optionc', 'option3', 'c']);
  const dCol = col(['optiond', 'option4', 'd']);
  const ansCol = col(['correct', 'answer', 'ans']);
  const solCol = col(['solution', 'explanation', 'sol']);

  if (qCol < 0 || aCol < 0 || bCol < 0 || cCol < 0 || dCol < 0 || ansCol < 0) {
    SpreadsheetApp.getUi().alert('Missing required columns. Need: question, optionA, optionB, optionC, optionD, correct');
    return;
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/\\/g, '\\\\')
      .replace(/`/g, '\\`')
      .replace(/\$/g, '\\$');
  }

  let js = '// Generated from Google Sheets\n\nconst QUESTIONS = [\n';
  let count = 0;

  for (let r = 1; r < data.length; r++) {
    const row = data[r];
    const question = String(row[qCol] || '').trim();
    if (!question) continue;

    const options = [
      String(row[aCol] || '').trim(),
      String(row[bCol] || '').trim(),
      String(row[cCol] || '').trim(),
      String(row[dCol] || '').trim()
    ];
    if (options.some(o => !o)) continue;

    let correct = parseInt(String(row[ansCol]).trim(), 10);
    if (isNaN(correct)) {
      const letter = String(row[ansCol]).trim().toUpperCase();
      correct = letter.charCodeAt(0) - 64; // A=1
    }
    if (correct < 1 || correct > 4) continue;

    const solution = solCol >= 0 ? String(row[solCol] || '').trim() : '';

    if (count > 0) js += ',\n';
    js += '  {\n';
    js += '    question: `' + esc(question) + '`,\n';
    js += '    options: [\n';
    options.forEach(o => { js += '      `' + esc(o) + '`,\n'; });
    js += '    ],\n';
    js += '    correct_option_id: ' + (correct - 1) + ',\n';
    js += '    solution: `' + esc(solution) + '`\n';
    js += '  }';
    count++;
  }
  js += '\n];\n';

  if (count === 0) {
    SpreadsheetApp.getUi().alert('No valid questions found.');
    return;
  }

  // Show in a dialog for copy, and also create a downloadable file in Drive
  const html = HtmlService.createHtmlOutput(
    '<p><b>' + count + ' questions</b> ready.</p>' +
    '<p>Copy the code below, or use File → Make a copy from Drive after export.</p>' +
    '<textarea style="width:100%;height:280px;font-family:monospace;font-size:12px">' +
    js.replace(/</g, '&lt;') +
    '</textarea>'
  ).setWidth(640).setHeight(400);

  // Save to Drive
  const file = DriveApp.createFile('questions.js', js, MimeType.PLAIN_TEXT);
  SpreadsheetApp.getUi().showModalDialog(html, 'questions.js export');
  SpreadsheetApp.getUi().alert('Also saved to Google Drive as: ' + file.getName() + '\n\nFile ID: ' + file.getId());
}
```

### 3. Save and reload the sheet

- Click **Save** in Apps Script  
- Close the script tab and **reload** your Google Sheet  
- You should see a menu: **Quiz Export → Download questions.js**

### 4. Use the file

- Copy the code from the dialog into a new file `quizzes/my-quiz.js`  
  **or** download the file from Google Drive and rename it  
- Register the quiz in `config.js` (see main README)

---

## Column reference

| Column    | Required | Description                                      |
|-----------|----------|--------------------------------------------------|
| question  | Yes      | Question text                                    |
| optionA   | Yes      | Choice A                                         |
| optionB   | Yes      | Choice B                                         |
| optionC   | Yes      | Choice C                                         |
| optionD   | Yes      | Choice D                                         |
| optionE   | No       | Choice E (use converter with 5 options)          |
| optionF   | No       | Choice F (use converter with 6 options)          |
| correct   | Yes      | 1–4 (or A–D). 1 = A, 2 = B, …                    |
| solution  | No       | Explanation shown after submit                   |

---

## Tips

- Keep one sheet tab = one quiz  
- Don’t merge cells  
- Avoid line breaks inside a cell if pasting (or wrap the cell in quotes when using CSV)  
- After generating `questions.js`, always add the quiz entry in `config.js`
